JIGSAW CAPSTONE PROJECT
-----------------------
Submitted by
Somesh Ghaturle
-----------------------
PROJECT DETAILS
Client- Mobicom
-----------------------
Working domain- Telecom
-----------------------
Details : Mobicom is concerned that the market environment rising rate of customer churn and declining Average revenue per user will hit them even harder as the churn rate at Mobicom is relatively high.
-----------------------

