This is second project which is in python 
